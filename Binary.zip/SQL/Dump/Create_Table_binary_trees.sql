CREATE TABLE binary_trees (
                              id SERIAL PRIMARY KEY,
                              input_numbers TEXT NOT NULL,
                              tree_structure JSONB NOT NULL
);
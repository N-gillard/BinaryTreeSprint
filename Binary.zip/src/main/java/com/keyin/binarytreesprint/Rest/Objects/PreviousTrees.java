package com.keyin.binarytreesprint.Rest.Objects;

import java.util.List;

public class PreviousTrees {
    private List<String> treeNames;

    public PreviousTrees(List<String> treeNames) {
        this.treeNames = treeNames;
    }

    public List<String> getTreeNames() {
        return treeNames;
    }

    public void setTreeNames(List<String> treeNames) {
        this.treeNames = treeNames;
    }
}

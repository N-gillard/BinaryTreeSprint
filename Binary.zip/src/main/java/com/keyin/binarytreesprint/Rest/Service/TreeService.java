package com.keyin.binarytreesprint.Rest.Service;

import com.keyin.binarytreesprint.Rest.Entity.TreeData;

import java.util.List;

public interface TreeService {

    List<TreeData> getAllTrees();

    TreeData getTreeById(Long id);

    TreeData saveTree(TreeData tree);

    void deleteTree(Long id);
}
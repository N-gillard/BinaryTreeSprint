package com.keyin.binarytreesprint.Rest.Objects;

public class ProcessNumbers {
    private int sum;
    private int product;

    public ProcessNumbers(int sum, int product) {
        this.sum = sum;
        this.product = product;
    }

    public int getSum() {
        return sum;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    public int getProduct() {
        return product;
    }

    public void setProduct(int product) {
        this.product = product;
    }
}

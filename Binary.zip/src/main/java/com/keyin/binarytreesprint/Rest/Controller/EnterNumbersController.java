package com.keyin.binarytreesprint.Rest.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EnterNumbersController {

    @GetMapping("/Enter-Numbers")
    public String showEnterNumbersForm() {
        return "Enter-Numbers"; // assuming this maps to enter-numbers.html
    }

    @PostMapping("/Enter-Numbers")
    public String processEnteredNumbers() {
        return "redirect:/Previous-Trees";
    }
}

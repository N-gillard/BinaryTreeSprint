package com.keyin.binarytreesprint.Rest.Repository;

import com.keyin.binarytreesprint.Rest.Entity.TreeData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TreeDataRepository extends JpaRepository<TreeData, Long> {
}
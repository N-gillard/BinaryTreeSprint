package com.keyin.binarytreesprint.Rest.Service;
import com.keyin.binarytreesprint.Rest.Entity.TreeData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.keyin.binarytreesprint.Rest.Repository.TreeDataRepository;

import java.util.List;
import java.util.Optional;

@Service
public class TreeServiceImpl implements TreeService {

    private final TreeDataRepository treeDataRepository;

    @Autowired
    public TreeServiceImpl(TreeDataRepository treeDataRepository) {
        this.treeDataRepository = treeDataRepository;
    }

    @Override
    public List<TreeData> getAllTrees() {
        return treeDataRepository.findAll();
    }

    @Override
    public TreeData getTreeById(Long id) {
        Optional<TreeData> optionalTree = treeDataRepository.findById(id);
        return optionalTree.orElse(null);
    }

    @Override
    public TreeData saveTree(TreeData tree) {
        return treeDataRepository.save(tree);
    }

    @Override
    public void deleteTree(Long id) {
        treeDataRepository.deleteById(id);
    }
}
package com.keyin.binarytreesprint.Rest.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PreviousTreesController {

    @GetMapping("/Previous-Trees")
    public String showPreviousTrees() {
        return "Previous-Trees";
    }
}

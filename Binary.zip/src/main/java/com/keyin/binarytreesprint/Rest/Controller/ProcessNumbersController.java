package com.keyin.binarytreesprint.Rest.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProcessNumbersController {

    @PostMapping("/Process-Numbers")
    public ModelAndView processNumbers(Model model) {

        model.addAttribute("message", "Numbers processed successfully");

        return new ModelAndView("redirect:/Previous-Trees", model.asMap());
    }
}

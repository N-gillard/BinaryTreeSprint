package com.keyin.binarytreesprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BinaryTreeSprintApplication {

    public static void main(String[] args) {
        SpringApplication.run(BinaryTreeSprintApplication.class, args);
    }

}

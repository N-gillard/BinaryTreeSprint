package com.keyin.binarytreesprint.Rest.Controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.ui.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
public class EnterNumbersControllerTest {

    @Mock
    private Model model;

    @InjectMocks
    private EnterNumbersController enterNumbersController;

    @BeforeEach
    public void setUp() {
        // Setup any necessary mock objects or configurations
    }

    @Test
    public void testShowEnterNumbersForm() {
        String viewName = enterNumbersController.showEnterNumbersForm();
        assertEquals("Enter-Numbers", viewName);
        // Optionally, you can add more assertions here
    }

    @Test
    public void testProcessEnteredNumbers() {
        String viewName = enterNumbersController.processEnteredNumbers();
        assertEquals("redirect:/Previous-Trees", viewName);
        // Optionally, you can add more assertions here
    }

    // Optionally, you can add more test methods for other scenarios or edge cases
}

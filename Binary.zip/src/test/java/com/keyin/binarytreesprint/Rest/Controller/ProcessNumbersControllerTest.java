package com.keyin.binarytreesprint.Rest.Controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

public class ProcessNumbersControllerTest {

    @Mock
    private Model model;

    @InjectMocks
    private ProcessNumbersController processNumbersController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testProcessNumbersRedirect() {
        ModelAndView modelAndView = processNumbersController.processNumbers(model);
        RedirectView redirectView = modelAndView.getView() instanceof RedirectView ?
                (RedirectView) modelAndView.getView() : null;
        if (redirectView != null) {
            assertEquals("/Previous-Trees", redirectView.getUrl());
        } else {
            // If the view is not a RedirectView, fail the test
            assertEquals("/Previous-Trees", ""); // Fail the test
        }
    }

    @Test
    public void testProcessNumbersModel() {
        ModelAndView modelAndView = processNumbersController.processNumbers(model);
        verify(model).addAttribute("message", "Numbers processed successfully");
    }
}

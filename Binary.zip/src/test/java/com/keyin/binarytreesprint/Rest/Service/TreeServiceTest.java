package com.keyin.binarytreesprint.Rest.Service;

import com.keyin.binarytreesprint.Rest.Repository.TreeDataRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


public class TreeServiceTest {

    @Mock
    private TreeDataRepository treeDataRepository;

    @InjectMocks
    private TreeServiceImpl treeService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllTrees() {
        treeService.getAllTrees();

        Mockito.verify(treeDataRepository).findAll();
    }

}
